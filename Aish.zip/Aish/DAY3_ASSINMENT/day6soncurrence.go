  package main
  import "fmt"
  import "time"
  func hello(){
      fmt.Println("Go routine1")
      //time.sleep(1*time.Second)
  }
  func main(){
  go hello()
  time.sleep(5*time.second)
  fmt.Println("Main Function")
  }