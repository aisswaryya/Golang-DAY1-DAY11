package main
import "fmt"
func main(){
    children = []string{"Matthew", "Sarah", "Augustus","Heidi", "Emilie", "Peter", "Giana", "Adriano", "Aaron", "Elizabeth"}
    var total int=0
    for i:=0;i<len (children); i++{
    for _,j:=range children{
        switch(j){
                    case "a","A":{
                    total++
                    }
                    case "e","E":{
                        total++
                    }
                    case "i","I" :{
                        total+2
                    }
                    case"o","O" :{
                    total+3
                    }
                    case "u","U":{
                        total+4
                    }
               }
    }        

}
fmt.Println(total)
}