package main
import(
    "fmt"
    "time"
)
func main(){
	//var answer[10] string
	question:=[]string{"1.Go supports pointer arithmetics?",
		               "2.In Go language, Pointer types are derived types?",
		               "3.In Go language, Array types are inbuilt types?"}
    go  display(question)
	go getanswer(question)
	time.Sleep(150 * time.Second)
	//fmt.Println(answer[i])
                    
}
    
                    func display(question[] string){
                        for i:=0 ;i<len(question);i++{
						fmt.Println(question[i])
						time.Sleep(60 * time.Second)
                    }}
                    func getanswer(question [] string){
						var answer[10] string
                        for i:=0; i<len(question);i++{
						fmt.Scanln(&answer[i])
						time.Sleep(60 * time.Second)
					}
					fmt.Println(answer[1])
				}
                    
                    