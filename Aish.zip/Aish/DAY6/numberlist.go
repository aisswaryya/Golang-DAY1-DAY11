package  main
import "fmt"
import "time"

func one(){
    fmt.Println(" 1 2 3 4 5 6 7 8 9 10")
}

func two(){
    fmt.Println(" 11 12 13 14 15 16 17 18 19 20")
}

func three(){
    fmt.Println(" 21 22 23 24 25 26 27 28 29 30")
}

func four(){
    fmt.Println(" 31 32 33 34 35 36 37 38 39 40")
}
func five(){
    fmt.Println(" 41 42 43 44 45 46 47 48 49 50")
}
func main(){
    go one()
    time.Sleep(10*time.Millisecond)
    go two()
    time.Sleep(20*time.Millisecond)
    go three()
    time.Sleep(30*time.Millisecond)
    go four()
    time.Sleep(40*time.Millisecond)
    go five()
    time.Sleep(50*time.Millisecond)

}