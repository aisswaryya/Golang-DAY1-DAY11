package main
import(
    "fmt"
    
    "sync"
)
var balance int=10000
var wait sync.WaitGroup
var m sync.Mutex


func withdrawal(){
	m.Lock()
	//m:=balance
    var withdrawn int
    fmt.Println("Enter withdrawal amount")
    fmt.Scanln(&withdrawn)
    if(withdrawn>10000){
        fmt.Println("Insuffient Balance")
    } else {
	balance=balance-withdrawn
	//balance=available_balance
    fmt.Println(balance )
	}
	
	m.Unlock()
	wait.Done()
	//return bal
}


func deposit() {
    m.Lock()
    var deposit int
    fmt.Println("Enter deposit amount")
    fmt.Scanln(&deposit)
	balance=balance+deposit
	//bal:=available_balance
	fmt.Println(balance )
	
    m.Unlock()
	wait.Done()
	//return balance
}

func main(){
	wait.Add(2)
	fmt.Println("1.withdrawal\n","2.deposit\n")
	var input int
	fmt.Scanln(&input)
	go withdrawal( )
	go deposit()
/*	if(input==1){
		go withdrawal()
		
	} else {
		go deposit()
	}   */
	wait.Wait()
	} 