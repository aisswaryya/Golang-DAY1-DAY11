package main
import(

)
func main(){
  //  panic ("error situation")
    _,err:=10/0
    if err!=nil{
        panic (err)
    }
}