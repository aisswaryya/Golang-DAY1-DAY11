package main
import(
	"fmt"
	"time"
)
func p1(){
    fmt.Println("Roopesh")
}
func p2(){
    fmt.Println("the")
}
func p3(){
    fmt.Println("Kingslayer")
}

func main(){
    defer p3()
	go p2()
	time.Sleep(5*time.Second)
	go p1()
	time.Sleep(5*time.Second)
}