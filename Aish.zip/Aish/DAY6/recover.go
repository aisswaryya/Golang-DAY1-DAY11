package main
import(
    "fmt"
)
func divide(n1,n2 int)int{
   // defer func(){
     //   fmt.Println(recover())
    //}()
    q:=n1/n2
     return q;
}
func main(){
    fmt.Println(divide(10,0))
    fmt.Println(divide(10,2))
}