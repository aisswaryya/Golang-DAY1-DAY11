package main
import (
   "fmt"
   "net/http"
   "github.com/gorilla/mux"
)
func main() {
   r:=mux.NewRouter()
   r.HandleFunc("/books/{id}/name/{name}" ,
             func(w http.ResponseWriter,r *http.Request) {
    vars:=mux.Vars(r)
    id:=vars["id"]
    name:=vars["name"]
    fmt.Fprintf(w,"Your are requested %s and %s \n",id,name)
    fmt.Printf("server is ready in 8089")
      })
   http.ListenAndServe(":8089",r)
} 
