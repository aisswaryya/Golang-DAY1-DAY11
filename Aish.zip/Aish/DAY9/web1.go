package main
import(
	"fmt"
	"net/http"
)
func main(){
	http.HandleFunc("/",func(w http.ResponseWriter,r *http.Request){
		fmt.Fprintf(w,"Hiiiiiii  %s\n",r.URL.Path)
	})
	fmt.Printf("server is listenening to 8089")
	http.ListenAndServe(":8089",nil)
}                                                    