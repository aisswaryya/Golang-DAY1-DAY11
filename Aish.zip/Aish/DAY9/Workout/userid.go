package main

import ("fmt"
        "os"
        "strings"
        "bufio"
		//"strconv"
		//"time"
        )

  type employee struct {
  name string
  doj string
  domain string
}  
func generateId(){
	for i:=0;i<len(x[i]);i++
	str1=
}

var x[10] employee
var m map[string] employee
func main(){

    file,err:=os.Open("employee.txt")
  if err != nil {
        fmt.Println(err)  
	}
	var i int
scanner:=bufio.NewScanner(file)
for scanner.Scan(){
    readstring:=scanner.Text()

	var arr[] string=strings.Split(readstring,",")
	x[i].name=arr[0]
	x[i].doj=arr[1]
	x[i].domain=arr[2]
fmt.Println(x[i].name,x[i].doj,x[i].domain)
i++
}
defer file.Close()
 generateId()
}