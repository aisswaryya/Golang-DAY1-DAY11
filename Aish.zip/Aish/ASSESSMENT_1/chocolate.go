package main
import "fmt"
func main(){
     var children = []string{"Matthew", "Sarah", "Augustus","Heidi", "Emilie", "Peter", "Giana", "Adriano", "Aaron", "Elizabeth"}
    var total [10] int
    for i:=0;i<10; i++{
    for _,j:=range children[i]{
        switch(j){
                    case 'a','A':{
                    total[i]++
                    }
                    case 'e','E':{
                        total[i]++
                    }
                    case 'i','I' :{
                        total[i]+=2
                    }
                    case'o','O' :{
                    total[i]+=3
                    }
                    case 'u','U':{
                        total[i]+=4
					}
				
				}
			}
}
		for i:=0;i<10;i++{
			if(total[i]>10){
				total[i]=10
			}
			}	//fmt.Println(children[i])
		//	fmt.Println(total[i])
		var sum int
		for i:=0;i<10;i++{
			sum+=total[i]
		}

		  
		  // var left int
			//var coins int=50
			//left= coins-total[i]
			fmt.Println(sum)

			

			

	
}


