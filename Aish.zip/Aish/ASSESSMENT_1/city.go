package main
import(
    "fmt"
    )
    func getdata( city string)(string,string){
        if (city=="CHN" || city=="Chennai"){
			return "INDIA", "ASIA"
             }else if(city=="CBE" || city=="Coimbatore"){
                    return "INDIA","ASIA"
                    }else if(city=="BST" || city=="Boston"){
                    return "USA","AMERICA"} else {
                           return "Please check the data you have entered ","."
                           }
            }
       
    func main(){
        var a string
        fmt.Println("Enter city name")
        fmt.Scanln(&a)
        switch(a){
        case "CHN","Chennai":
         x,y:=getdata(a)
        fmt.Println(x,y)
        case "CBE","Coimbatore":
            z,h:=getdata(a)
			fmt.Println(z,h)
        case "BST","Boston":
            j,k:=getdata(a)
			fmt.Println(j,k)    
        default :
			b,c:=getdata(a)
			fmt.Println(b,c)
		} 
    }
    
