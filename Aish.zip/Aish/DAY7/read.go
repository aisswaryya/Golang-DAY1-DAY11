package main
import ("fmt"
"os")
func main(){
    file,err:=os.Open("file.txt")
    if err!=nil{
        fmt.Println("Error is: ",err)    
    }

fs:=make([]byte,10000)
_,err=file.Read(fs)
if(err!=nil){
            fmt.Println("Error is: ",err)    
}
fmt.Println()
str:=string(fs)

fmt.Println(str)
 file.Close()

}