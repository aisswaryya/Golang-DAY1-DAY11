package main
import (
    "fmt"
	"os"
	"strings"
	"bufio"
	"strconv"
    )
 type  product struct{
     id int
     model string
     manufacturer string
     price int
 }
 var structarray[5] product
 func main(){
mess,err:=os.Open("gadget.txt")
if (err!=nil){
    fmt.Println(err)
}
scanner:=bufio.NewScanner(mess)
var i int
fmt.Println("Available Products")
for scanner.Scan(){
	readString:=scanner.Text()
	var sarr[] string= strings.Split(readString,",")

structarray[i].id,err=strconv.Atoi(sarr[0])
structarray[i].model=(sarr[1])// allready in string format
structarray[i].manufacturer=(sarr[2])// default string format
structarray[i].price,err=strconv.Atoi(sarr[3])

fmt.Println(structarray[i].id,structarray[i].model,structarray[i].manufacturer,
	structarray[i].price)
i++
}
 var input_id int
 fmt.Scanln(&input_id)
 for i:=0;i<3;i++{
 if(structarray[i].id==input_id){
	fmt.Println(structarray[i].price)
 }

}}













    
