package main
import(
    "fmt"
)
type loan interface{
    getemi() float64
}
type housingloan struct{
 principal float64
    
}
type personalloan struct{
  principal float64
}
func(obj1 housingloan) getemi()(float64){
     emi:=(0.09*obj1.principal)

return emi
}
func(obj2 personalloan) getemi()(float64){
     emi:=(0.12*obj2.principal)
     return emi
}
func calculate(l loan){
fmt.Println(l.getemi())

}


func main(){
    fmt.Println("Type 1 for Housing Loan and 2 for Personal Loan")
    var input float64
    fmt.Scanln(&input)
    var principal float64
    fmt.Println("Enter the principal amount")
    fmt.Scanln(&principal)
    if(input==1){
        obj1:= housingloan{principal}
calculate(obj1)
    } else if(input==2){
        obj2:=personalloan{principal}
        calculate(obj2)
    } else {
        fmt.Println("Invalid Input")
    }
    
}