package main
import(
	"fmt"
	"io/ioutil"
	"strings"
)
func main(){
	mess,err:=ioutil.ReadFile("text.txt")
	if err!=nil{
		fmt.Println("Error is:",err)
	}
	str:=string(mess)
	fmt.Println(str)
	fmt.Println(strings.ToUpper(str))
	var sarray[] string
	for i:=0;i<len(str);i++{
		sarray=strings.Split(str,"\n")
	}
	fmt.Println("The no of words in text.txt is")
	fmt.Println(len(sarray))
	var count int
	for i:=0;i<len(str);i++{
	if(str[i]=='a' || str[i]=='A'||str[i]=='e' || str[i]=='E'||str[i]=='i' || str[i]=='I'||str[i]=='o' || str[i]=='O'||str[i]=='u' || str[i]=='U'){
		count++
	}
}
fmt.Println("Number of vowels in the file is")
fmt.Println(count)
}