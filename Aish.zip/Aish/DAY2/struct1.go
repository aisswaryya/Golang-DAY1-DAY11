package main
import "fmt"
type Student struct{
    name string
    age int
}
func main(){
	var a string
	var b int
	s1:= Student{a,b}
	fmt.Scanln(&a)
	fmt.Scanln(&b)
	s1.name=a
	s1.age=b
    fmt.Println(a,b)
}