package main
import "fmt"
func main(){
    var age int
    loop:
    fmt.Printf("Enter age")
    fmt.Scanln(&age)
    if(age<=18){
    goto loop1
}else{
    fmt.Println("You can vote")
}
break
loop1:
fmt.Println("Not elligible")
goto loop
}