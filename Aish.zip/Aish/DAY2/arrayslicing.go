package main
import "fmt"
func main(){
    var x[5] int 
    var i int
    for i=0;i<5;i++{
        fmt.Scanln(&x[i])
    }
    for i=0;i<5;i++{
        fmt.Printf("Inex [%d]= %d \n" ,i,x[i])
    }
    s1:=x[2:3]
    fmt.Println(s1)
}