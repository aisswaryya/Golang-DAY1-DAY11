package main
import "fmt"
func main(){
    var x int =3
    var ptr=&x
    fmt.Println("Pointers")
    fmt.Println(x)
    fmt.Println(ptr)
    fmt.Println(*ptr)
    *ptr=39
    fmt.Println(x)
}