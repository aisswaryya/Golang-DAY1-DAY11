package main
import "fmt"
type database struct{
    name string
    age int
}
func  (s database)getdetails()(string,int){
    fmt.Scanln(&s.name)
    fmt.Scanln(&s.age)
    return s.name,s.age
    }
func main(){
    s1:=database{}
    x,y:=s1.getdetails()
    fmt.Println("name",x)
    fmt.Println("Age",y)
}