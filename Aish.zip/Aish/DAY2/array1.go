package main
import "fmt"
func main(){
    a:=[]int {2,3,6,7}
    //sum:=0
    for i,value:=range a{
		
      if value==6{
    
	fmt.Println("output",i)
	  }
	}
}

