package main
import "fmt"
func fun(a int ,b int) (int,int){
		return a*b,a+b}
    func main(){
        x,y:=fun(3,9)
        fmt.Println(x,y)
      //  fmt.Println(fun(23,39))
    }