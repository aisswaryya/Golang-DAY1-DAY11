package main
import(
    "fmt"
    "os"
)
func main(){
    
    //for i,a:=range os.Args[1:]{
        pname:=os.Args[1]
    m1:=os.Args[2]
    m2:=os.Args[3]
    m3:=os.Args[4]
    fmt.Printf(" Name is:%s\n" ,pname)
    fmt.Printf(" Subject1 : %d\n" ,m1)
    fmt.Printf(" Subject2 : %d\n" ,m2)
    fmt.Printf(" Subject3 : %d\n" ,m3)
    }cd ..
}