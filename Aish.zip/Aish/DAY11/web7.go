package main
import (
	"fmt"
	"net/http"
	"github.com/gorilla/mux"
	
)

func home(w http.ResponseWriter,varr  *http.Request){
	fmt.Fprintf(w,"Welcome to Cognizant")
}

func CONTACTUS(w http.ResponseWriter,varr  *http.Request){
	fmt.Fprintf(w,"104,John Mathew Street,")
	fmt.Fprintf(w,"Texas")
	fmt.Fprintf(w,"USA")
}

func ABOUTUS(w http.ResponseWriter,varr  *http.Request){
	fmt.Fprintf(w,"AAAAAAA")
	fmt.Fprintf(w,"BBBBBBBBB")
}


func main (){
	
	r:=mux.NewRouter()
	r.HandleFunc("/HOME",home)

r.HandleFunc("/CONTACT US",CONTACTUS)


r.HandleFunc("/ABOUT US",ABOUTUS)


	fmt.Printf("Server is ready at 9099")
	http.ListenAndServe(":9099",r)
	                                        
}