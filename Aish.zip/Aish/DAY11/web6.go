package main
import (
	"fmt"
	"net/http"
	"github.com/gorilla/mux"
	"strconv"
)
type SI struct{
	principle int64
	duration int64
	roi int64 
}
func main (){
	s:=SI{}
	r:=mux.NewRouter()
	r.HandleFunc("/{principle}/{duration}/{roi}",
	func (w http.ResponseWriter,varr  *http.Request){
		x:=mux.Vars(varr)
	
	str1:=x["principle"]
    u,err:=strconv.ParseInt(str1,0,64)
	s.principle=u

	str2:=x["duration"]
    y,err:=strconv.ParseInt(str2,0,64)
	s.duration=y
	
	str3:=x["roi"]
    z,err:=strconv.ParseInt(str3,0,64)
	s.roi=z
	if(err!=nil){

	}

		fmt.Fprintf(w,"Simple Interest of %d , %d and %d \n ",u,y,z)
	    fmt.Fprintf(w,"%d",(s.principle*s.duration*s.roi)/100)
	})
	fmt.Printf("Server is ready at 9099")
	http.ListenAndServe(":9099",r)
	                                        
}