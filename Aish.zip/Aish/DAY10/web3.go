package main
import (
	"fmt"
	"net/http"
	"github.com/gorilla/mux"
)
type book struct{
	id string
	name string
}
func main (){
	b:=book{}
	r:=mux.NewRouter()
	r.HandleFunc("/books/{id}/name/{name}",
	func (w http.ResponseWriter,r *http.Request){
		x:=mux.Vars(r)
		b.id=x["id"]
		b.name=x["name"]
		fmt.Fprintf(w,"You have requested %s and %s \n ",b.id,b.name)
		fmt.Println(b)
	})
	fmt.Printf("Server is ready at 9099")
	http.ListenAndServe(":9099",r)
}