package main
import (
   "fmt"
   "encoding/json"
   "net/http"
   "github.com/gorilla/mux"
)
type Student struct {
  Id  string 
  Name  string 
}
type students []Student

func main() {
   r:=mux.NewRouter() //.StrictSlash(true)
   r.HandleFunc("/",Home)
   r.HandleFunc("/showall",ShowStudents)
   r.HandleFunc("/showstudent/{name}",ShowStudent)
   fmt.Printf("server is ready in 8088")
   http.ListenAndServe(":8088",r)
}
func Home(w http.ResponseWriter,r *http.Request) {
   fmt.Fprintf(w," Welcome\n")
}
func ShowStudent(w http.ResponseWriter,r *http.Request) {
   vars :=mux.Vars(r)
   name :=vars["name"] 
   fmt.Fprintf(w,"Studnet details :%s\n",name)   
}
func ShowStudents(w http.ResponseWriter,r *http.Request) {
   s := students {
                  Student{Id:"10",Name:"Kiran"},
                  Student{Id:"11",Name:"Raj"},
   }
   json.NewEncoder(w).Encode(s
)
}
