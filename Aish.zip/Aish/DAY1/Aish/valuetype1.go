package main
import "fmt"
func main(){
var i int 
var b bool 
var s string 
var f float64
fmt.Println("%T \n",i)
fmt.Println("%V \n",i)
fmt.Println("     ")
fmt.Println("     ")

fmt.Println("%T \n",b)
fmt.Println("%V \n",b)
fmt.Println("     ")
fmt.Println("     ")


fmt.Println("%Q \n",s)
fmt.Println("     ")
fmt.Println("     ")

fmt.Println("%T ",f)
fmt.Println("%V ",f)
fmt.Println("     ")
fmt.Println("     ")
}