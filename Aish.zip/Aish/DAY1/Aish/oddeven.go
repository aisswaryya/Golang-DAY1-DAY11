package main
import "fmt"
func main(){
var a int = 39
if(a%2==0){

fmt.Println("Even")
}else{
fmt.Println("Odd")
}
}
