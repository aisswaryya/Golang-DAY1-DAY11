package main
import "fmt"
func main(){
const l int=3
const w int=9
var a =l*w
fmt.Printf("Area= %V \n",a)
fmt.Println("Area= ",a)
}
