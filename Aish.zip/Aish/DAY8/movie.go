package main
import(
	"fmt"
	
)
type movies struct{

	language string
    releaseDate string
    director string
	producer st
	mring
    duration int
}

/*func display(moviename string,m map[string] movie){
	//fmt.Println(m)
	for i:=0;i<len(m);i++{
	fmt.Println(m[moviename])
}
	}
	*/

func main(){
	var m=map[string]movies {"MA": movies{"English","10/10/2015","Speilsberg","Richie Rich",120},
	"MMB": movies{"English","10/10/2016","Speilsberg","Richie Rich",120},
	"MC": movies{"English","10/10/2017","Speilsberg","Richie Rich",120},
	"MD": movies{"Englishc","10/10/2018","Speilsberg","Richie Rich",120}}
	for _,value:= range m {
		fmt.Println(value.language,value.releaseDate,value.director,value.producer,value.duration,"\n")
	}
	var mov string
	fmt.Print("Enter movie to delete: ")
	fmt.Scanln(&mov)
	delete(m, mov)  
	for _,value:= range m {
		fmt.Println(value.language,value.releaseDate,value.director,value.producer,value.duration,"\n")
	}





	/*var m= map[string] movie{
		"Before Sunrise":movie{"english","03-09-1996","Nicholas Sparks","dreamworks",2,},
		"Before sunset":movie{"french","09-02-1996","Nikil Stephen","glassfish",1,},
	}
	fmt.Println("Enter 1 for display and 2 to delete details")
	var input int
	var moviename string
	fmt.Scanln(&input)
	if(input==1){
		fmt.Println("Enter the movie name for which u need 2 get the details ")
		fmt.Scanln(&moviename)
display(moviename,m)
	} else if(input==2){
		fmt.Println("Enter the movie name u need 2 delete")
		
		fmt.Scanln(&moviename)
	delete(m,moviename)

	for _,value:=range m{
		fmt.Println(value.language,value.Releasedate,value.director,value.producer,value.duration)
	}
	}       */
}
