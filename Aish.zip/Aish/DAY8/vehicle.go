package main
import(
	"fmt"
	
)
type vehicle[] string 
type employee struct{
	name string
	designation string
	salary float64
    v vehicle
}
func main(){
	var m= map[int] employee{
		1:employee{"aaa","1stgrade",10000,vehicle{"car"},},
		2:employee{"bbb","2ndgrade",20000,vehicle{"bike"},},
	}
	 var input int
	 fmt.Scanln(&input)
	fmt.Println(m[input])

}
