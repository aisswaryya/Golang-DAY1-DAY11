package main
import "fmt"
type cust struct{
    id int 
    name string
}
func main(){
    c:=[4] cust{}
    for i:=0;i<=3;i++{
        //x:=cust{id:1,name:"cts"}
		//c=append(c,x)
		fmt.Scanln(&c[i].id)
		fmt.Scanln(&c[i].name)
    }
    fmt.Println(c)
}