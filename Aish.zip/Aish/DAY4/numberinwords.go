    package main
    import (
        "fmt"
	)
	func main(){
    var dig1,dig2,dig3,n int
	fmt.Printf("Enter a 3 digit number\n")
	fmt.Scanln(&n)
	dig1=n/100
	dig2=(n%100)/10
	dig3=(n%10)
    
	switch(dig1){
	case 1:fmt.Printf("one hundred")
	case 2:fmt.Printf("two hundred")
	case 3:fmt.Printf("three hundred")
	case 4:fmt.Printf("four hundred")
	case 5:fmt.Printf("five hundred")
	case 6:fmt.Printf("six hundred")
	case 7:fmt.Printf("seven hundred")
	case 8:fmt.Printf("eight hundred")
	case 9:fmt.Printf("nine hundred")
	}
if(dig2==1){
	switch(dig3){
    case 1:fmt.Printf(" and eleven")
	case 2:fmt.Printf(" and twelve")
	case 3:fmt.Printf(" and thirteen")
	case 4:fmt.Printf(" and fourteen")
	case 5:fmt.Printf(" and fivteen")
	case 6:fmt.Printf(" and sixteen")
	case 7:fmt.Printf(" and seventeen")
	case 8:fmt.Printf(" and eighteen")
	case 9:fmt.Printf(" and nineteen")
} } else {
	switch(dig2){
	case 2:fmt.Printf(" and twenty")
	case 3:fmt.Printf(" and thirty")
	case 4:fmt.Printf(" and fourty")
	case 5:fmt.Printf(" and fivty")
	case 6:fmt.Printf(" and sixty")
	case 7:fmt.Printf(" and seventy")
	case 8:fmt.Printf(" and eighty")
	case 9:fmt.Printf(" and ninety")
	}
}
if(dig2>1){
switch(dig3){
	case 1:fmt.Printf(" one")
	case 2:fmt.Printf(" two")
	case 3:fmt.Printf(" three")
	case 4:fmt.Printf(" four")
	case 5:fmt.Printf(" five")
	case 6:fmt.Printf(" six")
	case 7:fmt.Printf(" seven")
	case 8:fmt.Printf(" eight")
	case 9:fmt.Printf(" nine")
}
}
}

	
  
  
    