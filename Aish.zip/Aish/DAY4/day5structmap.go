package main
import "fmt"
type cust struct{
id int
name string
}
var c map[string] cust
func main(){
    c=make(map[string]cust)
    c["java"]=cust{1,"raj"}
    c["golang"]=cust{2,"Kiran"}
    fmt.Println(c["java"],c["go lang"])
    fmt.Println(c)
    for k,v:=range c{
        fmt.Println(k,v)
    }
}
