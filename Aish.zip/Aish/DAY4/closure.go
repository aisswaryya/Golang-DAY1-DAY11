package main
import "fmt"
func main(){
	sayhello:= func() string{
		return "hello"
	}
	sum :=func(a int,b int)int{
		return a*a+b*b

	}
	fmt.Println(sayhello())
fmt.Println(sum(39,11))
fmt.Println("Welcome to closure")
}