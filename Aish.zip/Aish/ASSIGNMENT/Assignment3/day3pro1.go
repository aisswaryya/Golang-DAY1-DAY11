package main
import(
    "fmt"
    "os"
   "strconv"
)
func main(){
    pname:=os.Args[1]
    m1:=os.Args[2]
    m2:=os.Args[3]
    m3:=os.Args[4]
    fmt.Printf(" Name is:%s\n" ,pname)
    fmt.Printf(" Subject1 : %s\n" ,m1)
    fmt.Printf(" Subject2 : %s\n" ,m2)
    fmt.Printf(" Subject3 : %s\n" ,m3)
    tm1,err:=strconv.ParseInt(m1,0,64)
    tm2,err:=strconv.ParseInt(m2,0,64)
    tm3,err:=strconv.ParseInt(m3,0,64)
    if err==nil{}
     total:=tm1+tm2+tm3
     average:=float64(total)/3
        fmt.Println(total)   
        fmt.Printf("%.2f",average) 
    }
