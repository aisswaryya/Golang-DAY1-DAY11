package main
import "fmt"
func main(){
	var children = []string{"smith", "aarav", "arya", "kiran", "john","peter", "giana", "Adriano", "Aaron", ""}
	var total int
	var coins int=50
        for i := 0; i < len(children[i]); i++ {
			switch string(children[i]) {
			case "a", "A":
				total++
			case "e", "E":
				total++
			case "i", "I":
				total++ 
			case "o", "O":
				total++
			case "u", "U":
				total++
			}
		}
		// fmt.Println(total)
     if (total==1 || total==0){
				total++
			}
		
			
		   	 left:= coins - total
		
		
		fmt.Println("Coins left:", left)
	}
		 
	


