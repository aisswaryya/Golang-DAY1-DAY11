package main
import(
    "fmt"
    )
    func getdata( state string)(string,string){
        if (state=="TN" || state=="Tamilnadu"){
			return "Panneer", "Chennai"
             }else if(state=="KT" || state=="Karnataka"){
                    return "SidhaRamaiya","Bangalore"
                    } else {
                           return "not found","not found"
                           }
            }
       
    func main(){
        var a string
        fmt.Println("Enter state name")
        fmt.Scanln(&a)
        switch(a){
        case "TN","Tamilnadu":
         x,y:=getdata(a)
        fmt.Println(x,y)
        case "KT","Karnataka" :
            z,h:=getdata(a)
			fmt.Println(z,h)
        default :
			b,c:=getdata(a)
			fmt.Println(b,c)
		} 
    }
    
