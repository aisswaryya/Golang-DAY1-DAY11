package main
import "fmt"
func main(){
var a string
fmt.Scanln(&a)
if(a == "a" || a=="e" || a=="i"|| a=="o" || a=="u"){
fmt.Println("Vowel")
} else if(a=="A" || a=="E" || a=="I" || a=="O" || a=="U"){
fmt.Println("Vowel")
 } else {
fmt.Println("Consonant")
}
}