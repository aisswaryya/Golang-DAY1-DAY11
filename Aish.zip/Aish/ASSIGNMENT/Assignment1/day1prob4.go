package main
import "fmt"
func main(){
	var amt float64
	
    var tax float64
    fmt.Scanln(&amt)
    if(amt<=240){
	 fmt.Println("0")
    }else if(amt>240 && amt<480){
        tax =(.15*amt)
        fmt.Println(tax)
    }else if(amt>480){
        tax =(.28*amt)
        fmt.Println(tax)
    }
}
