package main
import "fmt"
func main(){
    var num int
    var i  int 
    var count int=0
    fmt.Scanln(&num)
   if(num!=1 && num!=2 ){
			for i=2 ;i<num-1;i++{
				if(num%i==0){
					count++
				}
			}
					if(count==2){
						fmt.Println("Not a Prime")
					} else if(count<2){
						fmt.Println("Prime")
					}
       
   } else if(num==2){
	   fmt.Println("Prime")
   } else if(num==1){
       fmt.Println("Not a Prime")
   }
}

