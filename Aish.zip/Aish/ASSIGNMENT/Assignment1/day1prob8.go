package main
import "fmt"
func main(){
	var unit float64
	var a, b, c,d  = 4.0,4.50,4.75,5.0
    var amount float64
    fmt.Scanln(&unit)
    if(unit<=100){
		amount = (a*unit)
		if(amount>250){
			fmt.Println(amount)
		} else {
			fmt.Println("250")
		}
    }else if(unit>100 && unit<=300){
        amount =(b*unit)
        fmt.Println(amount)
    }else if(unit>300 && unit<500){
        amount =(c*unit)
        fmt.Println(amount)
    } else if(unit>500){
		amount= (d*unit)
		fmt.Println(amount)
	}
}