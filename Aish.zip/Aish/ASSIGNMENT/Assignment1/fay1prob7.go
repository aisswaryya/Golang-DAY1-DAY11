package main
import "fmt"
func main(){
    var customer float64
    var expense float64
    var income float64
	var profit float64
	fmt.Scanln(&customer)
    expense= (20.05* customer)
	income= (customer*5)
	if(expense>income){
		profit=expense-income
	fmt.Println("loss = ",profit)
	}else if(income>expense){
		profit =income-expense
    fmt.Println("profit = ",profit)
}
}