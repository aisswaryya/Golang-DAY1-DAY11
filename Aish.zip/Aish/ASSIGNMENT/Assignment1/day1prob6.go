package main
import "fmt"
func main(){
    var num int
    var i  int 
    var count int=0