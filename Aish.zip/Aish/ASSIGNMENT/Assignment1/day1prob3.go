package main
import "fmt"
func main(){
	var amt float64
	var a, b, c = .04,.045,.05
    var interest float64
    fmt.Scanln(&amt)
    if(amt<=1000){
		
        interest =a*amt
        fmt.Println(interest)
    }else if(amt>1000 && amt<=5000){
        interest =(b*amt)
        fmt.Println(interest)
    }else if(amt>5000){
        interest =(c*amt)
        fmt.Println(interest)
    }
}