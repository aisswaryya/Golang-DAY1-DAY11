  package main
import "fmt"
func  main(){
 var a int 
var b int 
var c int 
var max int
    fmt.Scanln(&a)
    fmt.Scanln(&b)
    fmt.Scanln(&c)
    if(a>b && a>c){
        max=a
    }else if(b>a && b>c){
      max=b

    }else {
        max=c
    }
    fmt.Printf("%v ",max)
}

     

