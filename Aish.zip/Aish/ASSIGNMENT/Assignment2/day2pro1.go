package main
import "fmt"
func factorial(num int) int{
	
	var fact int=1
	for i:=1;i<=num ;i++{
	  fact=i*fact
}
return fact
}

func main(){
	var num int
	fmt.Println("Enter the number")
	fmt.Scanln(&num)   
	x:=factorial(num)    
	fmt.Println(x)                                        
	                                                                                                                                                                                         
                                                                                                                                                                                                                                     
}
	


