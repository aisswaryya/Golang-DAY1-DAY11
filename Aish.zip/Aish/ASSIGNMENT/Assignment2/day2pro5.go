package main
import "fmt"
func main(){
    var a,b,c,input int
    fmt.Println("Enter first number")
    fmt.Scanln(&a)
    fmt.Println("Enter second number")
    fmt.Scanln(&b)
    fmt.Println("SELECT ONE OPERATION")
    fmt.Println("0 for Add")
    fmt.Println("1 for Subtract")
    fmt.Println("2 for Multiply")
    fmt.Println("3 for Divide")
    fmt.Scanln(&input)
    switch(input){
        case 0:
        c=a+b
         fmt.Println(c)
         case 1:
         c=a-b
         fmt.Println(c)
         case 2:
         c=a*b
         fmt.Println(c)
         case 3:
         c=a/b
         fmt.Println(c)
         default:fmt.Println("Invalid Input\n")
    }
}