package main
import "fmt"
func size (a[5] int) (int,int){
	var max int=0

	for i:=0;i<5;i++{
    if(max<a[i]){
        max=a[i]
	}}

var min int=a[0]
		for i:=0;i<5;i++{
        if(min>a[i]){
            min=a[i]
		}}
	return max,min
}
    

func main(){
   var a[5] int
   var i int
	fmt.Println("Enter the array elements")
	for i=0;i<5;i++{
	fmt.Scanln(&a[i])
	}
    x,y:=size(a)
    
    fmt.Println("Largest number",x)
    fmt.Println("Smallest number",y)

}