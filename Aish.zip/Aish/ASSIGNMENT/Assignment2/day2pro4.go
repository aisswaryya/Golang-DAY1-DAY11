package main
import "fmt"
type product struct{
    id int 
    name string
   quantity float64
   unitprice float64
   totalprice float64
}
func (p product)getdata()(int,string,float64,float64){
    fmt.Println("ID:")
    fmt.Scanln(&p.id)
    fmt.Println("NAME:")
    fmt.Scanln(&p.name)
    fmt.Println("QUANTITY:")
    fmt.Scanln(&p.quantity)
    fmt.Println("UNITPRICE:")
    fmt.Scanln(&p.unitprice)
    return p.id,p.name,p.quantity,p.unitprice
}

func main(){
    var totalprice float64
    obj:=product{}
    a,b,c,d:=obj.getdata()
totalprice=c*d
fmt.Println(a,"\n",b,"\n",c,"\n",d,"\n",totalprice)    
}