package main
import "fmt"
func largest (a[10] int) int{
	var max int=0
	var i int
	for i=0;i<10;i++{
    if(max<a[i]){
        max=a[i]
	}}
	return max
}
    func Smallest (a[10] int)int{
		var min int=a[0]
		var i int
		for i=0;i<10;i++{
        if(min>a[i]){
            min=a[i]
		}}
		return min
    }

func main(){
   var a[10] int
   var i int
	fmt.Println("Enter the array elements")
	for i=0;i<10;i++{
	fmt.Scanln(&a[i])
	}
    x:=largest (a)
    y:=Smallest (a)
    fmt.Println("Largest number",x)
    fmt.Println("Smallest number",y)

}
