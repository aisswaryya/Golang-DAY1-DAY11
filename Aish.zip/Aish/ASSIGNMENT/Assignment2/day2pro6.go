package main
import "fmt"
type bank struct{
    accnum int 
    balance float64
   }
func (b bank)getdata()(int){
    fmt.Println("ACCOUNT NUMBER:")
    fmt.Scanln(&b.accnum)
    return b.accnum
}
func(b bank)withdrawal()(float64,float64){
    var withdrawal,amount,balance float64
    fmt.Println("Enter the withdrawal amount")
	fmt.Scanln(&withdrawal)
	fmt.Println("BALANCE:")
    fmt.Scanln(&b.balance)
    amount=balance-withdrawal
    return balance,amount
}
func(b bank)deposit()(float64,float64){
    var deposit,amount,balance float64
    fmt.Println("Enter the deposit amount")
	fmt.Scanln(&deposit)
	fmt.Println("BALANCE:")
    fmt.Scanln(&balance)
    amount=balance+deposit
    return balance,amount
}

func main(){
    var num int
       obj:=bank{}
	a:=obj.getdata()
	fmt.Println("Acc no:",a)
	//fmt.Println("Balance:",b)
fmt.Println("Choose")
fmt.Println("1 for Deposit")
fmt.Println("2 for Witdrawal")
fmt.Scanln(&num)
if(num==1){
    b,c:=obj.deposit()
    fmt.Println("Amount",b)
    fmt.Println("Present Balance after deposit",c)
} else if (num==2){
    d,e:=obj.withdrawal()
    fmt.Println("Amount",d)
    fmt.Println("Present Balane after withdrawal",e)
} else {
    fmt.Println("Service unavailable")
}

}