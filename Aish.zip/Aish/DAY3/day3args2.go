package main
import(
    "fmt"
    "os"
)
func main(){
    argcount:=len (os.Ars[1:])
    fmt.Println("Total no of aruments:%d\n",argcount)
}
