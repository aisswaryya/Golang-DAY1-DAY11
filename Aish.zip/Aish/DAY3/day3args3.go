package main
import(
    "fmt"
    "os"
)
func main(){
    argcount:=len (os.Args[1:])
    fmt.Println("Total no of arguments:%d\n",argcount)

    for i,a:=range os.Args[1:]{
        fmt.Printf("arguments %d is %s\n",i+1,a)
    }
}
