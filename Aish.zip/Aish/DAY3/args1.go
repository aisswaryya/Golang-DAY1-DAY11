package main
import(
    "fmt"
    "os"
)
func main(){
    pname:=os.Args[0]
    name:=os.Args[1]
    fmt.Printf("Proram Name is:%s\n" ,pname)
    fmt.Printf(" Name is:      %q\n" ,name)
}
